from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
# This is the file where database strata are assigned
class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    notes = db.relationship('Note')
    score_h=db.Column(db.Integer)
    score_true=db.Column(db.Integer)
    ST_type=db.Column(db.String(150))
    ST_string=db.Column(db.String(150))
    course=db.Column(db.Integer)
    assign = db.relationship('Ass')
    assign2 = db.relationship('Ass_Resp')
class Ass(db.Model):
    Ass_id = db.Column(db.Integer, primary_key=True)
    Ass_text = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    course=db.Column(db.Integer)
    type=db.column(db.String(100))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
class Ass_Resp(db.Model):
    Ass_id = db.Column(db.Integer, primary_key=True)
    Ass_text = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    course=db.Column(db.Integer)
    label_a=db.Column(db.String(10000))
    maker_id=db.Column(db.String(10000))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))