from flask import Blueprint, request, flash, render_template, redirect, url_for
from psutil import users
from .models import User,Ass,Note, Ass_Resp
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required, logout_user, current_user
from bs4 import BeautifulSoup


auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST']) # 'methods' contains the types of accepted HTTP requests
def login():
    if request.method == 'POST':
        email = request.form.get('email') # Retrieves the 'email' tag from the database 
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user: 
            if check_password_hash(user.password, password):
                flash('Logged in successfully!', category='success')
                login_user(user, remember=True)
                return redirect(url_for('views.home'))  # command used to go to another page
            else:
                flash('Incorrect password, try again.', category='error')
        else:
            flash('Email does not exist.', category='error')

    return render_template("login.html", user=current_user) # displays 'Login' on page via html

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login')) # redirects user to login page

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        password1 = request.form.get("password1")
        password2 = request.form.get("password2")
        score= request.form.get('postId')
        S_or_T= request.form.get("age")
        classnum=request.form.get("class")
        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 1:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 1:
            flash('Password must be at least 7 characters.', category='error')
        else:   
            if S_or_T=="student":
                stringy="student123"
                flash(S_or_T)
                flash(stringy)
                flash(classnum)
                score=0
            else:
                stringy="teacher123"
                flash('Welcome Teacher')
                flash(S_or_T)
                flash(stringy)
                flash(classnum)
                score=1
            
            new_user = User(email=email, first_name=first_name,score_h=score,score_true=0, ST_type=S_or_T,ST_string=stringy,course=classnum, password=generate_password_hash(password1, method='sha256'))
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')
            
            return redirect(url_for('views.home'))
            
            
    return render_template("sign_up.html", user=current_user,student="student",teacher="teacher")

@auth.route('/rewards', methods = ['GET', 'POST'])
def rewards():
    books=current_user.course
    return render_template("rewards.html", user=current_user,rock=books)
        
    
@auth.route('/quiz', methods = ['GET', 'POST'])
def quiz():

    return render_template("student-take-quiz.html", user=current_user)
    

@auth.route('/quizResults', methods = ['GET', 'POST'])
def quizResults():
    return render_template("student-quiz-results.html", user=current_user)

@auth.route('/arcade', methods = ['GET', 'POST'])
def arcade():
    #where 
    if request.method == 'POST':
        pts = request.form.get('note')
        new_points = Note(data=pts, user_id=current_user.id)
        db.session.add(new_points)
        db.session.commit()
        flash('Points added!', category='success')
    return render_template("arcade.html", user=current_user)

@auth.route('/progress', methods = ['GET', 'POST'])
def progress():
    x=current_user.course
    rows=User.query.all()
    return render_template("progress.html", user=current_user, key=x, values2=rows)


@auth.route('/profile', methods = ['GET', 'POST'])
def profile():
    return render_template("profile.html", user=current_user)

@auth.route('/customrewards', methods = ['GET', 'POST'])
def customrewards():
    return render_template("customrewards.html", user=current_user)

@auth.route('/PointsE', methods = ['GET', 'POST'])
def PointsE():
    if current_user.score_h==0:
        return render_template("PointsE_Stud.html", user=current_user)
    else:
        key2=int(current_user.course)
        ##where we add points
        if request.method=='POST':
            hold_text = request.form.get('custID')
            current_user.score_true += 1
            db.session.commit()
            x=current_user.course
            flash(hold_text)
            flash(x)
            new_assign = Ass(Ass_text=hold_text,course=x,type='bolo')
            db.session.add(new_assign)
            db.session.commit()
            flash(hold_text)
            flash(current_user.score_h)
        return render_template("PointsE_Teach.html", user=current_user,table2=Ass_Resp,key=key2,values2=2)

@auth.route('/Assign', methods = ['GET', 'POST'])
def Assign():
    if current_user.score_h==0:
        key2=int(current_user.course)
        ##where we add points
        x=int(current_user.course)
        g=int(current_user.course)
        rows=2
        print(type(rows))
        if request.method=='POST':
            StuAname = request.form.get('WhatA')
            StuAsub = request.form.get('Whatsub')
            new_assign = Ass_Resp(Ass_text=StuAsub,label_a=StuAname, course=current_user.course,maker_id=current_user.first_name)
            db.session.add(new_assign)
            db.session.commit()
        return render_template("Ass_Student.html", user=current_user, key=g, values2=rows,chao=db,table2=Ass)
    else:
        if request.method=='POST':
            hold_text = request.form.get('text1')
            x=current_user.course
            new_assign = Ass(Ass_text=hold_text,course=x,type='bolo')
            db.session.add(new_assign)
            db.session.commit()
        return render_template("Ass_Teach.html", user=current_user)

@auth.route('/tempo', methods = ['GET', 'POST'])
def tempo():
    rows=str(User.query.all())

    return rows

@auth.route('/quizEdit', methods = ['GET', 'POST'])
def instructor_quiz_edit():
    if current_user.score_h==0:
        return render_template("Teach_Only.html", user=current_user)
    else:
        return render_template("instructor-quiz-edit.html", user=current_user)  

@auth.route('/viewCourses', methods = ['GET', 'POST'])
def instructor_view_courses():
    if current_user.score_h==0:
        return render_template("Teach_Only.html", user=current_user)
    else:
        return render_template("instructor-view-courses.html", user=current_user)

@auth.route('/editCourses', methods = ['GET', 'POST'])
def instructor_edit_courses():
    if current_user.score_h==0:
        return render_template("Teach_Only.html", user=current_user)
    else:
        return render_template("instructor-edit-courses.html", user=current_user)